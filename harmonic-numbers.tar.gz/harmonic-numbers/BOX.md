# Box: harmonic-numbers

A short computation of H(n) for n = 1,000,000, its gap to ln(n) + gamma, and the first n with H(n) > 10.

- Title: Harmonic numbers and the Euler-Mascheroni constant
- Created: 2026-11-20; dropped: 2026-11-20
- Prepared for: Shareable readers
- Default sharing: Shareable
- Author: A. Researcher
- Topics: harmonic numbers; Euler-Mascheroni constant

## Contents

| Item | Kind | Live link | Snapshot | Sharing | Notes |
| --- | --- | --- | --- | --- | --- |
| Computation | code | none | code/harmonic.py | Shareable |  |

## State at drop time

- The gap matches 1/(2n) to five digits.

## Reproduce

Harmonic sums can be rerun from this drop:

```
python3 code/harmonic.py
```

- Requires: Python 3, standard library only
- Expected: out/results.json: H = 14.392726722865724 within 1e-12 relative; gap = 5e-07 within 1e-05 relative; first_n_over_10 = 12367
- Expected: stdout: the text 'H(1000000) = 14.392726722866'

Run `build_box.py <this folder> --reproduce`: it checks the drop's checksums, shows the command, asks before running it on a temporary copy, and reports whether the result reproduced. Running it executes this box's code with your permissions; it is not a sandbox.

## Integrity

manifest-sha256.txt holds a checksum of every snapshot file, and tagmanifest-sha256.txt covers this file, box.json and the RO-Crate description. They show whether the files still match what was dropped; they do not show that the content is correct. Cite a snapshot by box name, drop date and checksum.
